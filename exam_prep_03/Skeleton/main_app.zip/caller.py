import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import TennisPlayer
from django.db.models import Count


# Create queries within functions
def get_tennis_players(search_name=None, search_country=None):
    if search_name is None and search_country is None:
        return ""

    if search_name is not None and search_country is not None:
        result = TennisPlayer.objects.filter(
            full_name__icontains=search_name,
            country__icontains=search_country
        ).order_by('ranking')

    elif search_name is not None and search_country is None:
        result = TennisPlayer.objects.filter(
            full_name__icontains=search_name
        ).order_by('ranking')

    elif search_name is None and search_country is not None:
        result = TennisPlayer.objects.filter(
            country__icontains=search_country
        ).order_by('ranking')

    if not result.exists():
        return ""

    return "\n".join(f"Tennis Player: {x.full_name}, country: {x.country}, ranking: {x.ranking}"
                     for x in result)


def get_top_tennis_player():
    top_player = TennisPlayer.objects.get_tennis_players_by_wins_count().first()

    if not top_player or top_player.wins_count == 0:
        return ""

    return (f"Top Tennis Player: {top_player.full_name} "
            f"with {top_player.wins_count} wins.")


def get_tennis_player_by_matches_count():
    top_player = (
        TennisPlayer.objects
        .annotate(num_matches=Count('matches'))
        .order_by('-num_matches', 'ranking')
        .first()
    )

    if not top_player or top_player.num_matches == 0:
        return ""

    return (f"Tennis Player: {top_player.full_name} "
            f"with {top_player.num_matches} matches played.")
